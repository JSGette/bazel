def fixture(name):
    native.genrule(name = name, srcs = native.glob(["inputs/*.txt", "optional/*.txt"], allow_empty = True) + ["link.txt"], outs = ["result.txt"], cmd = "cat $(SRCS) > $@")
