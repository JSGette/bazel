def _impl(ctx):
    out = ctx.actions.declare_file(ctx.label.name + ".sh")
    ctx.actions.write(out, ctx.attr.script, is_executable=True)
    return [DefaultInfo(executable=out)]
proof_test = rule(implementation=_impl, test=True, attrs={"script": attr.string()})
